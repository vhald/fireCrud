import {createStore, combineReducers, applyMiddleware, compose} from 'redux';
import newsCategoriesReducer from './newsCategoriesReducer';
import newsPostsReducer from './newsPostsReducer';
import newsCommentsReducer from './newsCommentsReducer';
import thunk from 'redux-thunk';

// //enhancer : 1. thunk 2.
// //27 sept for devtools
// import {composeWithDevTools} from 'remote-redux-devtools';
// import {composeWithDevTools} from 'redux-devtools-extension';
var composeEnhancers = compose;
if (__DEV__) {
  composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
}

const reducers = combineReducers({
  posts: newsPostsReducer,
  categories: newsCategoriesReducer,
  comments: newsCommentsReducer,
});

const store = createStore(reducers, composeEnhancers(applyMiddleware(thunk)));

export default store;
