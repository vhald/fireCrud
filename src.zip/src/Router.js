import React, {useState, useEffect} from 'react';
import {View, Text} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
// import {createDrawerNavigator} from '@react-navigation/drawer';
import {GoogleSignin} from '@react-native-google-signin/google-signin';

import HomePage from './App';
import AddPage from './Screens/AddPage';
import DetailPage from './Screens/DetailPage';
import EditPage from './Screens/EditPage';
import RoughPage from './Screens/RoughPage';
import LoginPage from './Screens/LoginPage';
import PushNotif from './Screens/PushNotif';
import ShareLib from './Screens/ShareLib';
import AddCategory from './Screens/AddCategory';
import CategoryList from './Screens/CategoryList';

import auth from '@react-native-firebase/auth';
import messaging from '@react-native-firebase/messaging';
import SplashScreen from 'react-native-splash-screen';

import {Provider} from 'react-redux';
import store from './redux/store/store';

const Stack = createNativeStackNavigator();
// const Drawer = createDrawerNavigator();

function App(props) {
  const [state, setState] = useState({loading: true, currentUser: null});
  // useEffect(() => {
  //   const currentUser = auth().currentUser;
  //   console.log('currentUser on router', currentUser);
  //   setState(prev => ({...prev, currentUser, loading: false}));
  // }, []);

  // useEffect(() => {
  //   auth().onAuthStateChanged(user => {
  //     if (user) {
  //       // User is signed in, see docs for a list of available properties
  //       // https://firebase.google.com/docs/reference/js/firebase.User
  //       var uid = user.uid;
  //       console.log('uid onAuthStateChanged', uid);
  //       setState(prev => ({...prev, currentUser: uid, loading: false}));
  //       // ...
  //     } else {
  //       // User is signed out
  //       // ...
  //       console.log('user is signed out');
  //       setState(prev => ({...prev, currentUser: null, loading: false}));
  //     }
  //   });
  // }, []);

  // export async function requestUserPermission() {
  //   const authStatus = await messaging().requestPermission();
  //   const enabled =
  //     authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
  //     authStatus === messaging.AuthorizationStatus.PROVISIONAL;
  //   if (enabled) {
  //     getfcmToken();
  //   }
  // }

  // const getfcmToken = async () => {
  //   let fcmToken = await Storage.getData('fcmToken');
  //   console.log(fcmToken, ' Already generate token');
  //   if (!fcmToken) {
  //     try {
  //       const fcmToken = await messaging().getToken();
  //       if (fcmToken) {
  //         console.log(fcmToken, ' new generate token');
  //         await Storage.saveData('fcmToken', fcmToken);
  //       } else console.log('Hello React-Native' + fcmToken);
  //     } catch (error) {
  //       console.log(error + ' error aya re!');
  //     }
  //   }
  // };

  // export const notificationListner = async () => {
  //   messaging().setBackgroundMessageHandler(async remoteMessage => {
  //     console.log('Message handled in the background!', remoteMessage);
  //   });
  //   messaging().onNotificationOpenedApp(remoteMessage => {
  //     console.log(
  //       'Notification caused app to open from background state:',
  //       remoteMessage.notification,
  //     );
  //   });

  useEffect(() => {
    SplashScreen.hide();

    auth().onAuthStateChanged(user => {
      console.log('user');
      if (user) {
        var uid = user.uid;
        console.log('uid onAuthStateChanged', uid);
        setState(prev => ({...prev, currentUser: uid, loading: false}));
      } else {
        console.log('user is signout');
        setState(prev => ({...prev, currentUser: null, loading: false}));
      }
    });

    getRequest();

    // when you app will be in the foreground
    const unsubscribe = messaging().onMessage(async remoteMessage => {
      Alert.alert('A new FCM message arrived!', JSON.stringify(remoteMessage));
      // if(remoteMessage.data.url === 'google'){
      //
      // }
    });

    messaging().setBackgroundMessageHandler(async remoteMessage => {
      //console.log('Message handled in the background!', remoteMessage);
    });
  }, []);
  // const LoginPage = () => {
  //   const currentUser = auth().currentUser;
  //   console.log('currentUser on router', currentUser);
  //   setState(prev => ({...prev, currentUser, loading: false}));
  // };

  useEffect(() => {
    GoogleSignin.configure({
      webClientId:
        '460774933374-1up8d6g3guhk5t79o5oddrmp7bpqppl2.apps.googleusercontent.com',
    });
  }, []);

  // messaging().getToken();
  const getRequest = async () => {
    const authStatus = await messaging().requestPermission();
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;

    if (enabled) {
      //console.log('Authorization status:', authStatus);
      getToken();
    }
  };

  const getToken = () => {
    messaging()
      .getToken()
      .then(token => {
        //console.log('token for notifications',token)
        // if(auth().currentUser === null){
        //     firestore().collection('unregistedusers').add({ token: token })
        // }
        // else {
        //   firestore().collection('users').doc(auth().currentUser.uid).update({ token: token })
        // }
      })
      .catch(error => {
        //console.log('erro to get a token',error)
      });

    //taxi > employees, drivers , customers // all
    messaging()
      .subscribeToTopic('customers')
      .then(() => {
        //console.log('subscribeed to topic customers')
      });
  };

  const loginPage = () => {
    const currentUser = auth().currentUser;
    //console.log('currentUser on router page',currentUser)
    setstate(prev => ({...prev, currentUser, loading: false}));
  };

  return (
    <Provider store={store}>
      <NavigationContainer>
        <Stack.Navigator>
          {!state.currentUser ? (
            <Stack.Screen name="Login" component={LoginPage} />
          ) : (
            <>
              <Stack.Screen
                name="Home"
                component={HomePage}
                options={{headerShown: false}}
              />
              <Stack.Screen name="Add" component={AddPage} />
              <Stack.Screen name="Details" component={DetailPage} />
              <Stack.Screen name="Edit" component={EditPage} />
              <Stack.Screen name="Rough" component={RoughPage} />
              <Stack.Screen name="PushNotif" component={PushNotif} />
              <Stack.Screen name="Share" component={ShareLib} />
              <Stack.Screen name="addcategory" component={AddCategory} />
              <Stack.Screen name="categorylist" component={CategoryList} />
            </>
          )}
        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}

export default App;
